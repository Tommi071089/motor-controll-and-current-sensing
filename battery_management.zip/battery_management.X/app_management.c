/*
 * File:   app_management.c
 * Author: M67252
 *
 * Created on December 28, 2022, 2:43 PM
 */


#include <xc.h>
#include "app_management.h"
#include "mcc_generated_files/uart1.h"
BAT_STATES BAT_states = STATE_INIT;
uint16_t poti = 0;
uint16_t batAdc = 0;

float voltage = 0;
float batVoltage = 0;
uint16_t timer1Flag = 0;

void TMR1_CallBack(void) {
//    timer1Flag = 1;
        ADC1_SoftwareTriggerEnable();
        poti = ADCBUF23;
        batAdc = ADCBUF22;
        voltage = (float)(poti * MAX_VOLTAGE / ADC_MAX_COUNT);
        batVoltage = (float)(batAdc * MAX_VOLTAGE / ADC_MAX_COUNT);
        printf("ADC Count = %u, Voltage = %0.2f\n\r", poti,voltage);
}

//void batterManagement(void) {
////    if (timer1Flag) {
////        timer1Flag = 0;
////        ADC1_SoftwareTriggerEnable();
////        poti = ADCBUF23;
////        batAdc = ADCBUF22;
////        voltage = (float)(poti * MAX_VOLTAGE / ADC_MAX_COUNT);
////        batVoltage = (float)(batAdc * MAX_VOLTAGE / ADC_MAX_COUNT);
////        printf("ADC Count = %u, Voltage = %0.2f\n\r", poti,voltage);
//
////        printf("ADC Count = %u, Battery Voltage = %0.2f\n\r", batAdc, batVoltage);
//
//    }
//}

void BAT_Task(void) {

    switch (BAT_states) {
        case STATE_INIT:
//            batterManagement();
            BAT_states = STATE_BAT_FULL;
            break;
            
        case STATE_BAT_FULL:
            if (poti >= BATTERY_FULL) {
                LED5_SetHigh();
                LED4_SetHigh();
                LED3_SetHigh();
                LED2_SetHigh();
                LED1_SetHigh();
//                printf("Battery is full!\n\r");
                 BAT_states = STATE_BAT_HALF_FULL;
            break;
            }
           

        case STATE_BAT_HALF_FULL:
            if (poti <= BATTERY_FULL && poti > BATTERY_HALF_FULL) {
                LED5_SetLow();
                LED4_SetHigh();
                LED3_SetHigh();
                LED2_SetHigh();
                LED1_SetHigh();
                 BAT_states = STATE_BAT_ALMOST_EMPTY;
            break;
            }
           

        case STATE_BAT_ALMOST_EMPTY:
            if (poti <= BATTERY_HALF_FULL && poti > BATTERY_ALMOST_EMPTY) {
                LED5_SetLow();
                LED4_SetLow();
                LED3_SetHigh();
                LED2_SetHigh();
                LED1_SetHigh();
                BAT_states = STATE_BAT_EMPTY;
            break;
            }
            

        case STATE_BAT_EMPTY:
            if (poti <= BATTERY_ALMOST_EMPTY && poti > BATTERY_EMPTY) {
                LED5_SetLow();
                LED4_SetLow();
                LED3_SetLow();
                LED2_SetHigh();
                LED1_SetHigh();
                 BAT_states = STATE_RECHARGE_BAT;
            break;
            }
           

        case STATE_RECHARGE_BAT:
            if (poti <= BATTERY_EMPTY && poti > RECHARGE_BATTERY) {
                LED5_SetLow();
                LED4_SetLow();
                LED3_SetLow();
                LED2_SetLow();
                LED1_SetHigh();
                 break;
            }
           

        default:
            break;

    }

}